package ar.org.centro8.poo.tp3_venta_camaras.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LautaroAlonsoCutacTnTp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
