package ar.org.centro8.poo.tp3_venta_camaras.java.models.entities;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Venta {
    private int id_venta;
    private int id_clienteFK;
    private int id_camaraFK;
    private double precio_total;
    private LocalDate fecha_venta;
}
