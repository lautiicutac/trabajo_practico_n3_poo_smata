package ar.org.centro8.poo.tp3_venta_camaras.java.models.enums;

public enum Tipo_camara {
    DSLR, MIRRORLES, COMPACTA;
}
