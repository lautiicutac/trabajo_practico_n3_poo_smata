package ar.org.centro8.poo.tp3_venta_camaras.java.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.poo.tp3_venta_camaras.java.models.entities.Camara;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.enums.TipoCamara;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.CamaraDAO;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.ClienteDAO;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.VentaDAO;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.interfaces.I_CamaraDAO;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.interfaces.I_ClienteDAO;
import ar.org.centro8.poo.tp3_venta_camaras.java.models.repositories.interfaces.I_VentaDAO;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.poo.tp3_venta_camaras.java")

public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_CamaraDAO camaraDAO = context.getBean(CamaraDAO.class);
            I_ClienteDAO clienteDAO = context.getBean(ClienteDAO.class);
            I_VentaDAO ventaDAO = context.getBean(VentaDAO.class);

            //EXPERIMENTO TEST 001: Crear una nueva camara
            System.out.println("\n---   Test 1: creando una nueva camara...    ---");
            Camara camaraNueva = new Camara(0, "Canon", "R7", TipoCamara.MIRRORLES, 32.2, "RF", "18-150mm", "Febrero 2023", "Camara Mirrorless con crop x1.6", 3560000, 29);
        }
    }
}
