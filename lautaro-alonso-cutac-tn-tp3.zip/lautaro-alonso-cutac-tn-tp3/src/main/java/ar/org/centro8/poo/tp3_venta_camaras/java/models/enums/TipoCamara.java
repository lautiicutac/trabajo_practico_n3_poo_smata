package ar.org.centro8.poo.tp3_venta_camaras.java.models.enums;

public enum TipoCamara {
    DSLR, MIRRORLES, COMPACTA;
}
