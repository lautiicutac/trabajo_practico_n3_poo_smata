package ar.org.centro8.poo.tp3_venta_camaras.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LautaroAlonsoCutacTnTp3Application {

	public static void main(String[] args) {
		SpringApplication.run(LautaroAlonsoCutacTnTp3Application.class, args);
	}

}
