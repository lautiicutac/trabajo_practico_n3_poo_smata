package ar.org.centro8.poo.tp3_venta_camaras.java.models.entities;

import ar.org.centro8.poo.tp3_venta_camaras.java.models.enums.Tipo_camara;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Camara {
    private int id;
    private String marca;
    private String modelo;
    private Tipo_camara tipo_camara;
    private double megapixeles;
    private String tipo_de_montura;
    private String lente_kit;
    private String fecha_de_lanzamiento;
    private String descripcion;
    private double precio;
    private int stock;
}
